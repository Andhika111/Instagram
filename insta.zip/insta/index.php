<?php
session_start();

if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";
$sql = "SELECT * FROM post ORDER BY no DESC";
$query = mysqli_query($koneksi, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SummerAdventure</title>
    <link rel="shortcut icon" href="images/kuning.png" type="image/x-icon" style="width:200px;" alt="">
    <link rel="stylesheet" href="css/6.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <style>    
      body{
      margin: 0;
      padding: 0;
      background: url(foto/beachh.jpeg) no-repeat;
      background-attachment: fixed;
      font-family: sans-serif;
      background-size: cover;
      background-repeat: no-repeat ;
      background-position: center;
    }
      .zoom {
        overflow: hidden;
      }
      .zoom img{
        transition: transform .2s;
        margin: 0 auto;
      }
      .zoom:hover img{
        transform: scale(1.3);
      }
      /* background-attachment:fixed; */
        .geeks {

            width: 286px;
            height: 160px;
            overflow: hidden;
            margin: 0 auto;
        }

        .geeks img {
            width:100%;
            transition: 0.5s all ease-in-out;
        }

        .geeks:hover img {
            transform:scale(1.5);
        }
    </style>
</head>
<body class="" style="background-image: url('foto/beachh.jpeg')">
<!-- <body class="" style="background-color: #867070"> -->
    <br>
<nav class="navbar navbar-expand-lg fixed-top" style="background-color:#65451F" >
  <div class="container-fluid text-center">
  <a class = "navbar-brand" href = "kuning.png">
  <img src = "kuning.png" width="45" height = "45">
  </a>

    <a class="navbar-brand mb-0 h1"><strong>SummerADventure</strong></a>
    <!-- <button class="navbar-toggler" type="button" post-bs-toggle="collapse" post-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation"> -->
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
</ul>
<span class="navbar-text">
<button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="bi bi-upload"></i></button></a>
<!-- <a href="tambah.php"><button class="btn btn-light"><i class="bi bi-upload"></i></button></a>
</button> -->
    <a href="logout.php"><button class="btn btn-danger"><i class="bi bi-arrow-right-square"></i></button></a>
      <!-- <span class="navbar-toggler-icon"></span> -->
      
</span>
</div>
</nav>  
  <center>
    <div class="container mt-5">
    <?php while($post = mysqli_fetch_assoc($query)) { ?>

    <br><div class="card mx-auto mt-3" style="width: 18rem;">
    <div class="geeks">
    <img class="card-img-top" src="images/<?= $post['foto'] ?>" alt="Card image cap">
    </div>
    <div class="card-body">
    <ul class="list-group list-group-flush">
      <center>
    <li class="list-group-item"><strong><?= $post['caption'] ?></strong></li>
    <li class="list-group-item"><?= $post['lokasi'] ?></li>
    </center>
    </ul>
    <div class="card-footer">
    <center>
    <a href="hapus.php?no=<?=$post['no'] ?>"><i class=" btn btn-danger bi bi-trash3"></i></a>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editModal<?=$post['no']?>"><i class="bi bi-pencil-square"></i></button></a><br><br>
    </center>
    <center>
    <h6 style="color: #22668D">@summerdestination123</h6>
    </div>
    </div>
    </div>
    </div>
    </center>
   
   <br>
</body>
</html>



<!-- Modal -->
<body class="" style="background-image: url('foto/ok.jpg')">
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Upload</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" 
    enctype="multipart/form-data">
        <label for="">Foto</label>
        <input type="file" name="foto" class="form-control" id="" required><br>
        <label for="">Caption</label>
        <input type="text" name="caption" class="form-control" id="" autocomplete="off"><br>
        <label for="">Lokasi</label>
        <input type="text" name="lokasi" class="form-control" id="" autocomplete="off"><br><br>
        <input type="submit" value="simpan" name="simpan"  class="btn btn-info">
        <!-- <input type="submit" value="Simpan" class="btn btn-primary"> -->
    </form>

      <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      
      </div> -->
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="editModal<?=$post['no']?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="editModalLabel">Lux Country</h1>
      </div>
      <div class="modal-body">
      <form action="proses_edit.php" method="post" enctype="multipart/form-data">
      <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" class="form-control" value="<?= $post['foto'] ?>"><br>


        <label for="">Caption</label>
        <input type="text" name="caption" id="" class="form-control" value="<?= $post['caption'] ?>" autocomplete="off"><br>

        <label for="">lokasi</label>
        <input type="text" name="lokasi" id="" class="form-control" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        <label for="">Foto</label>
        <input type="file" name="foto" class="form-control" id="" value="<?= $post['foto'] ?>" ><br>
        <img src="images/<?= $post['foto'] ?>" width="100" alt="" ><br><br>
        
        
        <input class="btn btn-primary" type="submit" value="simpan" name="ubah">
    </form>
    </div>
</div>
    
    </div>
</div>

<?php } ?>
    </body>