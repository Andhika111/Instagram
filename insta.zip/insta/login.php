<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
    <style>
      img.tengah {
    display: block;
    margin-left: auto;
    margin-right: auto;
}
body{
    background-image: url('foto/holiday.jpeg');
}

    </style>
</head>

<body>

    <div class="wrapper">
    <div class="main-content">
    <div class="header ">
      </div>
      <form action="proses_login.php" method="post">
        
        <img src="images/kuning.png" class="tengah" style="width:200px;" alt="">
           <!-- <h2>Login</h2> -->
            <div class="input-group">
                <span class="icon">
                    <ion-icon name="person"></ion-icon>
                </span>
                <input type="text" name="username" placeholder="Username" class="input-1" autocomplete="off">
            </div>
            <div class="input-group">
                <span class="icon">
                    <ion-icon name="lock-closed"></ion-icon>
                </span>
                <input type="password" name = "password" placeholder="Password" class="input-2">
            </div>
            <!-- <div class="forgot-pass">
                <a href="#">Forgot Password?</a>
            </div> -->
            <button type="submit" class="btn">Login</button>
            <!-- <div class="sign-link">
                <p>Don't have an account? <a href="#" class="register-link">Register</a></p>
            </div> -->
        </form>
    </div>
    </form>

    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>