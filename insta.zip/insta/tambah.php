<!-- <?php
include "koneksi.php";
session_start();

if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <title>Document</title>
</head>
<body class="" style="background-color: #053B50">
<div class="container">
    <h1 class="text-center">Upload Rekomendasi Tempat</h1>
     <!-- <p>Anda login Sebagai : <?=$_SESSION['login'] ?> </p>    -->
    <form action="proses_tambah.php" method="post" 
    enctype="multipart/form-data">
        <label for="">Foto</label>
        <input type="file" name="foto" class="form-control" id="" required><br>
        <label for="">Caption</label>
        <input type="text" name="caption" class="form-control" id="" autocomplete="off"><br>
        <label for="">Lokasi</label>
        <input type="text" name="lokasi" class="form-control" id=""><br><br>
        <input type="submit" value="Simpan" name="simpan" class="btn btn-primary">
    </form>
</body>
</html> -->