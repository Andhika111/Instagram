<?php
session_start();
if(!isset($_SESSION['login'])) {
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";
require "functions.php";
$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Document</title>
</head>
<body class="" style="background-color: #867070">
<nav class="navbar navbar-expand-lg bg-body-tertiary sticky-top">
  <div class="container-fluid">
  <i class="fa-brands fa-instagram" style="font-size:35px;"></i>
   <a class="navbar-brand" href="index.php" style="font-family:monospace;"><strong>Edit</strong></a>
    <!-- <a class="navbar-brand" href="#"><img src="images/insta.png" width="25" alt="" srcset=""></a> -->
    <button class="navbar-toggler" type="button" post-bs-toggle="collapse" post-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
</ul>
<span class="navbar-text">
                <a href="tambah.php"><button class="btn btn-sm btn-primary" type="button"><i class="bi bi-plus-square"></i></button></a>
                <a href="logout.php"><button class="btn btn-sm btn-secondary" type="button"><i class="bi bi-box-arrow-right"></i></button></a>
            </span>

        <!-- <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" post-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" aria-disabled="true">Disabled</a>
        </li>
      </ul> -->
      <!-- <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form> -->
    </div>
  </div>
</nav>
<div class="container mt-4">
    <div class="card col-sm-6 mx-auto mt-4">
  <h5 class="card-header">Ubah Postingan</h5>
  <div class="card-body">
    <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="foto_lama" class="form-control" value="<?= $post['foto'] ?>"><br>


        <label for="">Caption</label>
        <input type="text" name="caption" id="" class="form-control" value="<?= $post['caption'] ?>" autocomplete="off"><br>

        <label for="">lokasi</label>
        <input type="text" name="lokasi" id="" class="form-control" value="<?= $post['lokasi'] ?>" autocomplete="off"><br>
        <label for="">Foto</label>
        <input type="file" name="foto" class="form-control" id="" value="<?= $post['foto'] ?>" ><br>
        <img src="images/<?= $post['foto'] ?>" width="100" alt="" ><br><br>
        
        
        <input class="btn btn-primary" type="submit" value="simpan" name="ubah">
    </form>
    </div>
</div>
    
    </div>
</body>
</html>

<?php } ?>